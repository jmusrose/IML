"""CREMA-D baseline package."""
